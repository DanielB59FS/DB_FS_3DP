basic camera movement controls:

keyboard:
WASD - movement
left shift - down
space - up
mouse - rotation

controller:
left axis stick - movement
right trigger - up
left trigger - down